|    TAG    | COUNT |    AUTHOR     | COUNT | DIRECTORY  | COUNT | SEVERITY | COUNT | TYPE | COUNT |
|-----------|-------|---------------|-------|------------|-------|----------|-------|------|-------|
| cve       |  2435 | dhiyaneshdk   |  1262 | http       |  7355 | info     |  3645 | file |   337 |
| panel     |  1123 | daffainfo     |   864 | file       |   337 | high     |  1686 | dns  |    25 |
| wordpress |   962 | dwisiswant0   |   803 | workflows  |   191 | medium   |  1503 |      |       |
| exposure  |   901 | pikpikcu      |   353 | network    |   136 | critical |  1009 |      |       |
| xss       |   895 | pussycat0x    |   349 | cloud      |    98 | low      |   265 |      |       |
| wp-plugin |   837 | ritikchaddha  |   326 | code       |    81 | unknown  |    38 |      |       |
| osint     |   804 | pdteam        |   297 | javascript |    56 |          |       |      |       |
| tech      |   674 | princechaddha |   260 | ssl        |    29 |          |       |      |       |
| lfi       |   647 | ricardomaia   |   232 | dns        |    22 |          |       |      |       |
| misconfig |   602 | geeknik       |   230 | dast       |    21 |          |       |      |       |
